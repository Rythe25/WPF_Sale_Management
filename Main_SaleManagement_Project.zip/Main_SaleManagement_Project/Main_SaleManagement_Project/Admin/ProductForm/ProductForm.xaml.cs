﻿using Main_SaleManagement_Project.Admin.ProductForm.modelClass;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Main_SaleManagement_Project.Admin.ProductForm
{
    /// <summary>
    /// Interaction logic for ProductForm.xaml
    /// </summary>
    public partial class ProductForm : Window
    {
        public ProductForm()
        {
            InitializeComponent();

            AddProductToDataGrid();
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private void Close_Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
        private void Minimize_Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void hint_search_text_MouseDown(object sender, MouseButtonEventArgs e)
        {
            search_text.Focus();
        }

        private void search_text_GotFocus(object sender, RoutedEventArgs e)
        {
            hint_search_text.Visibility = Visibility.Collapsed;
        }

        private void search_text_LostFocus(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(search_text.Text))
            {
                hint_search_text.Visibility = Visibility.Visible;
            }
        }

        private void Product_Filter_Button_Click(object sender, RoutedEventArgs e)
        {
            product_filter_button.IsEnabled = false;
            category_filter_button.IsEnabled = true;
        }

        private void Category_Filter_Button_Click(object sender, RoutedEventArgs e)
        {
            category_filter_button.IsEnabled = false;
            product_filter_button.IsEnabled = true;
        }

        private void Dashboard_Tab_Click(object sender, RoutedEventArgs e)
        {
            var productForm = new Main_SaleManagement_Project.Admin.DashboardForm.DashboardForm();
            productForm.Show();
            this.Close();
        }

        private void Lang_Button_Click(object sender, RoutedEventArgs e)
        {
            SetLang
            (
                ((Button)sender).Tag.ToString()
            );
        }

        private void SetLang(string lang)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo(lang);
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(lang);

            Application.Current.Resources.MergedDictionaries.Clear();

            ResourceDictionary resDict = new ResourceDictionary
            {
                Source = new Uri($"/Dictionary/Dictionary-{lang}.xaml", UriKind.Relative)
            };

            Application.Current.Resources.MergedDictionaries.Add(resDict);

            english_button.IsEnabled = true;
            khmer_button.IsEnabled = true;
            switch (lang)
            {
                case "en-US":
                    english_button.IsEnabled = false;
                    break;
                case "en-KH":
                    khmer_button.IsEnabled = false;
                    break;
            }
        }

        private void AddProductToDataGrid()
        {
            List<Product> products = new List<Product>();
            products.Add(new Product(1, "Pringles", "Chips", 12, "929671952", "17/07/2024", "01/05/2027"));
            products.Add(new Product(2, "Lays", "Chips", 13, "647132924", "29/08/2023", "24/05/2028"));
            products.Add(new Product(3, "Coca-Cola", "Soft Drink", 22, "790650523", "26/01/2024", "28/11/2027"));
            products.Add(new Product(4, "Red Bull", "Energy Drink", 16, "235022530", "26/08/2024", "02/06/2028"));
            products.Add(new Product(5, "Monster", "Energy Drink", 13, "500675001", "08/04/2023", "08/07/2028"));
            products.Add(new Product(6, "Snickers", "Chocolate", 17, "245308377", "30/04/2023", "18/04/2028"));
            products.Add(new Product(7, "KitKat", "Chocolate", 13, "329210743", "30/10/2025", "26/05/2027"));
            products.Add(new Product(8, "Hershey", "Chocolate", 14, "205846583", "07/10/2023", "26/02/2028"));
            products.Add(new Product(9, "Nescafé", "Coffee Packets", 15, "715941002", "30/04/2025", "21/09/2026"));
            products.Add(new Product(10, "Starbucks VIA", "Coffee Packets", 16, "254620812", "27/02/2023", "10/11/2027"));
            products.Add(new Product(11, "Maxwell House", "Coffee Packets", 17, "792450199", "18/08/2024", "17/07/2028"));
            products.Add(new Product(12, "Doritos", "Chips", 10, "567983246", "05/05/2024", "15/06/2027"));
            products.Add(new Product(13, "Cheetos", "Chips", 14, "342980542", "15/03/2023", "28/04/2027"));
            products.Add(new Product(14, "M&M's", "Chocolate", 18, "958731624", "10/06/2023", "22/09/2027"));
            products.Add(new Product(15, "Twix", "Chocolate", 12, "470128539", "02/08/2024", "19/12/2027"));
            products.Add(new Product(16, "Pringles", "Chips", 12, "929671952", "17/07/2024", "01/05/2027"));
            products.Add(new Product(17, "Lays", "Chips", 13, "647132924", "29/08/2023", "24/05/2028"));
            products.Add(new Product(18, "Coca-Cola", "Soft Drink", 22, "790650523", "26/01/2024", "28/11/2027"));
            products.Add(new Product(19, "Red Bull", "Energy Drink", 16, "235022530", "26/08/2024", "02/06/2028"));
            products.Add(new Product(20, "Monster", "Energy Drink", 13, "500675001", "08/04/2023", "08/07/2028"));
            products.Add(new Product(21, "Snickers", "Chocolate", 17, "245308377", "30/04/2023", "18/04/2028"));
            products.Add(new Product(22, "KitKat", "Chocolate", 13, "329210743", "30/10/2025", "26/05/2027"));
            products.Add(new Product(23, "Hershey", "Chocolate", 14, "205846583", "07/10/2023", "26/02/2028"));
            products.Add(new Product(24, "Nescafé", "Coffee Packets", 15, "715941002", "30/04/2025", "21/09/2026"));
            products.Add(new Product(25, "Starbucks VIA", "Coffee Packets", 16, "254620812", "27/02/2023", "10/11/2027"));
            products.Add(new Product(26, "Maxwell House", "Coffee Packets", 17, "792450199", "18/08/2024", "17/07/2028"));
            products.Add(new Product(27, "Doritos", "Chips", 10, "567983246", "05/05/2024", "15/06/2027"));
            products.Add(new Product(28, "Cheetos", "Chips", 14, "342980542", "15/03/2023", "28/04/2027"));
            products.Add(new Product(29, "M&M's", "Chocolate", 18, "958731624", "10/06/2023", "22/09/2027"));
            products.Add(new Product(30, "Twix", "Chocolate", 12, "470128539", "02/08/2024", "19/12/2027"));

            product_list.ItemsSource = products;
        }
    }
}
