﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Main_SaleManagement_Project.Admin.ProductForm.modelClass
{
    public class Product
    {
        public int Number { get; set; }
        public string ProductName { get; set; }
        public string Category { get; set; }
        public int Quantity { get; set; }
        public string ProductCode { get; set; }
        public string ProductEntryDate { get; set; }
        public string ProductExpireDate { get; set; }

        public Product(int number, string productName, string category, int quantity, string productCode, string productEntryDate, string productExpireDate)
        {
            Number = number;
            ProductName = productName;
            Category = category;
            Quantity = quantity;
            ProductCode = productCode;
            ProductEntryDate = productEntryDate;
            ProductExpireDate = productExpireDate;
        }
    }
}
