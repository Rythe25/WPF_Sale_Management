﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using LiveCharts;
using LiveCharts.Wpf;


namespace Main_SaleManagement_Project.Admin.DashboardForm
{
    /// <summary>
    /// Interaction logic for DashboardForm.xaml
    /// </summary>
    public partial class DashboardForm : Window
    {
        public SeriesCollection SeriesCollection { get; set; }

        // Sale
        public ChartValues<double> SalesValues { get; set; }
        public string[] SalesLabels { get; set; }

        // Product
        public string[] ProductLabels { get; set; }
        public Func<double, string> ProductFormatter { get; set; }

        // Stock
        public string[] StockLabels { get; set; }
        public Func<double, string> StockFormatter { get; set; }

        public DashboardForm()
        {
            InitializeComponent();

            Sale_Chart();
            Product_Chart();
            Stock_Chart();
        }

        private void Stock_Chart()
        {
            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = null,
                    Values = new ChartValues<double> { 10, -15, 20, -25, 30 }
                }
            };

            StockLabels = new[] { "January", "February", "March", "April", "May" };
            StockFormatter = value => value.ToString("N");

            StockBarChart.Series = SeriesCollection;
            StockBarChart.DataContext = this;
        }

        private void Product_Chart()
        {
            SeriesCollection = new SeriesCollection
            {
                new ColumnSeries
                {
                    Title = null,
                    Values = new ChartValues<double> { 10, -15, 20, -25, 30 }
                }
            };

            ProductLabels = new[] { "January", "February", "March", "April", "May" };
            ProductFormatter = value => value.ToString("N");

            ProductBarChart.Series = SeriesCollection;
            ProductBarChart.DataContext = this;
        }

        private void Sale_Chart()
        {
            DataContext = this;

            SalesValues = new ChartValues<double> { 3, 5, 7, 4, 6 };
            SalesLabels = new[] { "Jan", "Feb", "Mar", "Apr", "May" };
        }

        private void Border_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        private void Close_Button_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Minimize_Button_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        private void Product_Tab_Click(object sender, RoutedEventArgs e)
        {
            var productForm = new Main_SaleManagement_Project.Admin.ProductForm.ProductForm();
            productForm.Show();
            this.Close();
        }

        private void Lang_Button_Click(object sender, RoutedEventArgs e)
        {
            SetLang
            (
                ((Button)sender).Tag.ToString()
            );
        }

        private void SetLang(string lang)
        {
            Thread.CurrentThread.CurrentCulture = new CultureInfo(lang);
            Thread.CurrentThread.CurrentUICulture = new CultureInfo(lang);

            Application.Current.Resources.MergedDictionaries.Clear();

            ResourceDictionary resDict = new ResourceDictionary
            {
                Source = new Uri($"/Dictionary/Dictionary-{lang}.xaml", UriKind.Relative)
            };

            Application.Current.Resources.MergedDictionaries.Add(resDict);

            english_button.IsEnabled = true;
            khmer_button.IsEnabled = true;
            switch (lang)
            {
                case "en-US":
                    english_button.IsEnabled = false;
                    break;
                case "en-KH":
                    khmer_button.IsEnabled = false;
                    break;
            }
        }
    }
}
